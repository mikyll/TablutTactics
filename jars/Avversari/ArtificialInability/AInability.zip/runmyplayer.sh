#!/bin/bash

java -jar AInabilityClient.jar $@
